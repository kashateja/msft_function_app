############################### CODE FOR AIRTABLE API - TABLE_NAME - CROSS SELL COMBINED ############################

'''
importing libraries needed
if facing issue use pip install <library> to install a particular library
using python 3.9.2 version
Specific versions of libraries used
> pandas==1.2.3
> python-dotenv==0.15.0
'''
import os
import azure.functions as func
from dotenv import load_dotenv
import pyodbc
import datetime
import logging
import requests
import os
import json
import pandas as pd



'''
Function to get data from Airtable table using REST API
data is requested from endpoint and stored in a pandas dataframe - used json_normalise function to convert json type to tabular type
offset variable is used for pagination 
'''

def getdata(df,AIRTABLE_BASE_ID,AIRTABLE_TABLE_NAME,AIRTABLE_TOKEN,view):
    endpoint = f'https://api.airtable.com/v0/{AIRTABLE_BASE_ID}/{AIRTABLE_TABLE_NAME}'

    offset = '0'
    result = []
    while True :
        url = endpoint
        querystring = {
            "view":view,
            "api_key":AIRTABLE_TOKEN,
            "offset": offset}

        try :
            response= requests.get(url, params=querystring)
            response_Table = response.json()
            records = list(response_Table['records'])
            result.append(records)
           
            try :
                offset = response_Table['offset']
       
            except Exception:
           
                break

        except Exception:
            break


    for i in range(len(result)):
        if i ==0:
            df = pd.json_normalize(result[i],max_level=1)
        else:
            df = df.append(pd.json_normalize(result[i],max_level=1))
    
    return df

    
'''
Main Function based on Timer Trigger
A Timer Trigger will run based on Cron pattern which is specified in function.json file
Here we are using two different tables and joining them to create final dataframe
df_1 and df_2 are joined to form dfNew dataframe
used pyodbc library to connect to azure sql server and update the table with the data
'''


def main(mytimer: func.TimerRequest) -> None:
    
    load_dotenv()
    df = pd.DataFrame()

    AIRTABLE_BASE_ID = os.getenv("AIRTABLE_BASE_ID")
    AIRTABLE_TABLE_NAME = os.getenv("AIRTABLE_TABLE_NAME")
    AIRTABLE_TOKEN = os.getenv("AIRTABLE_TOKEN")
    SERVER = os.getenv("SERVER")
    DATABASE = os.getenv("DATABASE")
    USERNAME = os.getenv("USERNAME")
    PASSWORD = os.getenv("PASSWORD")
    view = "DO_NOT_TOUCH"
    DRIVER = 'ODBC Driver 17 for SQL Server'
    AIRTABLE_TABLE_NAME = ["Unicom Prospecting List - Webinars","Customer Contact Master Data","Organisation"]

    for i in AIRTABLE_TABLE_NAME:
        if i == "Unicom Prospecting List - Webinars":
            
            df_1 = getdata(df,AIRTABLE_BASE_ID,i,AIRTABLE_TOKEN,view)
            df_1 = df_1.reset_index(drop=True)
            
            df_1 = df_1.rename(columns={'fields.Email':'email', 'fields.Surname':'surname', 'fields.First Name':'first_name', 'fields.Webinar name':'webinar_name', 'fields.Source':'source', 'fields.Webinar date':'webinar_date', 'fields.Organisation (Linked)':'organisation_id', 
            'fields.Job Title':'job_title', 'fields.Customer or Prospect':'customer_or_prospect', 'fields.Quality of Lead':'quality_of_lead', 'fields.Attended/Non Attended':'attended_not_attended', 'fields.Sent Follow-up':'sent_follow_up', 'fields.Series':'series', 'fields.Lead Title':'lead_title',
            'fields.Email (Linked)':'email_linked_id','fields.Organisation (TEST)':'organisation_test','fields.Crunch Customer? (from Master Data - Auto filled)':'crunch_customer'})
            
            df_1 = df_1[['id','createdTime','email','first_name','surname','webinar_name','organisation_id','job_title','source','webinar_date','customer_or_prospect','quality_of_lead','attended_not_attended','lead_title','sent_follow_up','series','email_linked_id','organisation_test','crunch_customer']]

            df_1 = df_1.fillna('')
          
            df_1['organisation_id'] = df_1['organisation_id'].astype(str)
            df_1['attended_not_attended'] = df_1['attended_not_attended'].astype(str)
            df_1['attended_not_attended']  = df_1['attended_not_attended'].str[2:-2]
            df_1['email_linked_id'] = df_1['email_linked_id'].astype(str)
            df_1['email_linked_id']  = df_1['email_linked_id'].str[2:-2]
            df_1['crunch_customer'] = df_1['crunch_customer'].astype(str)
            df_1['crunch_customer']  = df_1['crunch_customer'].str[2:-2]
            df_1['organisation_test'] = df_1['organisation_test'].astype(str)
            df_1['organisation_id']  = df_1['organisation_id'].str[2:-2]
        
       
        elif i == 'Customer Contact Master Data':
            
            df_2 = getdata(df,AIRTABLE_BASE_ID,i,AIRTABLE_TOKEN,view)
            df_2 = df_2.reset_index(drop=True)
            df_2 = df_2.rename(columns={'id':'email_linked_id', 'fields.Email (Primary Field)':'email_linked'})
            df_2 = df_2[['email_linked_id','email_linked']]
            

        else:
            df_3 = getdata(df,AIRTABLE_BASE_ID,i,AIRTABLE_TOKEN,view)
            df_3 = df_3.reset_index(drop=True)
            df_3 = df_3.rename(columns={'id':'organisation_id', 'fields.Name':'organisation'})
            df_3 = df_3[['organisation_id','organisation']]
            

    dfNew = df_1.merge(df_3, on ='organisation_id', how='left')
    dfNew["organisation_id"] = dfNew["organisation"]
    dfNew = dfNew.drop(columns=['organisation'])
    dfNew = dfNew.rename(columns={'organisation_id': 'organisation'})
    dfNew['organisation'] = dfNew['organisation'].astype(str)
   
    dfNew = dfNew.merge(df_2, on ='email_linked_id', how='left')
    dfNew["email_linked_id"] = dfNew["email_linked"]
    dfNew = dfNew.drop(columns=['email_linked'])
    dfNew = dfNew.rename(columns={'email_linked_id': 'email_linked'})
    dfNew['email_linked'] = dfNew['email_linked'].astype(str)

    cnxn = pyodbc.connect('DRIVER='+DRIVER+';SERVER='+SERVER+';DATABASE='+DATABASE+';UID='+USERNAME+';PWD='+ PASSWORD)
    cursor = cnxn.cursor()
    cursor.execute("TRUNCATE TABLE airtable_unicom")

    for index, row in dfNew.iterrows():
        
        cursor.execute("INSERT INTO airtable_unicom (id, createdTime, email,first_name,surname,webinar_name,organisation,job_title,source,webinar_date,customer_or_prospect,quality_of_lead,attended_not_attended,lead_title,sent_follow_up,series,email_linked,organisation_test,crunch_customer) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row.id, row.createdTime, row.email,row.first_name,row.surname,row.webinar_name,row.organisation,row.job_title,row.source,row.webinar_date,row.customer_or_prospect,row.quality_of_lead,row.attended_not_attended,row.lead_title,row.sent_follow_up,row.series,row.email_linked,row.organisation_test,row.crunch_customer)

    cnxn.commit()
    cursor.close()
